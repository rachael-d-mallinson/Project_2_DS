package project_2;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;

public class InfixExpressionParcer {

   /**
	* Returns the precedence of an operator
	* @param oper: The operator to check
	* @return: The precedence of the operator
	* @throws: IllegalArgumentException: operator not supported
	*/
	private static int precedence(String oper) {
		if (oper.equals("^")) { return 7; }                                                                  //power
		if (oper.equals("*") || oper.equals("/") || oper.equals("%")) { return 6; }                           //arithmetic
		if (oper.equals("+") || oper.equals("-")) { return 5; }                                              //arithmetic
		if (oper.equals(">") || oper.equals(">=") || oper.equals("<") || oper.equals("<=")) { return 4; }    //comparison
		if (oper.equals("==") || oper.equals("!=")) { return 3; }                                             //equality comparison
		if (oper.equals("&&")) { return 2; }                                                                  //logical AND
		if (oper.equals("||")) { return 1; }                                                                  //logical OR
	         
		else { return 0; }	 
	}
	      
	/**
	 * Converts an infix expression to postfix expression.
	 * 
	 * @param infixExp: an infix expression with tokens separated by whitespaces
	 * @return: resulting postfix expression with tokens separated by whitespaces
	 */
	public static String infixToPostfix(String infixExp) {
		Scanner scanner = new Scanner(infixExp);
		// Initialize a stack.
		Stack<String> stack = new Stack<>();
		// Initialize the postfix expression.
		StringBuilder postfixExp = new StringBuilder();
		// Parse each token in the infix expression.
		while (scanner.hasNext()) {
			String token = scanner.next();
			// If the current token is an operand, append it to the postfix expression string
			if (Character.isDigit(token.charAt(0)) || (token.charAt(0) == '-' && token.length() > 1)) {
				postfixExp.append(token).append(' ');
			}
			// If the current token is opening parenthesis, push it onto the stack
			else if (token.equals("(")) {
				stack.push(token);
			}
			// The current token is closing parenthesis
			else if (token.equals(")")) {
				// Pop all operators from the stack, until an opening parenthesis is seen on top of the stack
				// Append each popped operator to the postfix expression string
				while (!stack.peek().equals("(")) {
					postfixExp.append(stack.pop()).append(' ');
				}
				// Pop the opening parenthesis from the stack
				stack.pop();
			} else {
				// The current token is an operator
				while (!stack.isEmpty() && !stack.peek().equals("(") && precedence(token) <= precedence(stack.peek())) {
					postfixExp.append(stack.pop()).append(' ');
				}
				// Push the current operator onto the stack
				stack.push(token);
			}
		}
		// Pop the remaining operators from the stack and append them to the postfix expression string.
		while (!stack.isEmpty()) {
			postfixExp.append(stack.pop()).append(' ');
		}
		scanner.close();
		return postfixExp.toString();
	} 
	

	/**
	  * Evaluates a postfix expression
	  * @param postfixExp: postfix expression with all integer operands
	  * @return: the evaluations result
	  * @throws: IllegalArgumentException: divide-by-zero
	  */
	 public static String evaluate(String postfixExp) {
		 Stack<Integer> stack = new Stack<>();
		 Scanner scanner = new Scanner(postfixExp);
		 
		 while (scanner.hasNext()) {
			 String token = scanner.next();
			 // If the token in an operand
			 if (Character.isDigit(token.charAt(0)) || (token.charAt(0) == '-' && token.length() > 1)) {
				 stack.push(Integer.valueOf(token));
			} else { // The token is an operator
				int right = stack.pop();
				int left = stack.pop();
				if (precedence(token) == 0) { return String.format("%s operator not supported.", token); }
				if (token.equals("^")) { stack.push((int)Math.pow(left,  right)); }
				if (token.equals("+")) { stack.push(left + right); }
				if (token.equals("-")) { stack.push(left - right); }
				if (token.equals("*")) { stack.push(left * right); }
				if (token.equals("/")) {
					if (right == 0) {
						return "Divide-by-zero error, could not evaluate expression.";
					} else { stack.push(left / right); }
				}
				if (token.equals("%")) { stack.push(left % right); }
				if (token.equals("<")) {  
					if (left < right) {stack.push(1); }
					else if (left >= right) { stack.push(0); }
				}
				if (token.equals(">")) {
					if (left > right) {stack.push(1); }
					else if (left <= right) { stack.push(0); }
				}
				if (token.equals(">=")) {
					if (left >= right) {stack.push(1); }
					else if (left < right) { stack.push(0); }
				}
				if (token.equals("<=")) {
					if (left <= right) {stack.push(1); }
					else if (left > right) { stack.push(0); }
				}
				if (token.equals("==")) {
					if (left == right) {stack.push(1); }
					else { stack.push(0); }
				}
				if (token.equals("!=")) {
					if (left != right) {stack.push(1); }
					else { stack.push(0); }
				}
				if (token.equals("||")) {
					if (left != 0 || right != 0) { stack.push(1); } 
					else { stack.push(0); }
				} 	
				else if (token.equals("&&")) {
					if (left != 0 && right != 0) { stack.push(1); } 	
					else { stack.push(0); }
				} 				
			}
		}
		scanner.close();
		return stack.peek().toString();	
	} 
	
	/**
	 * Adds spaces to an infix expression with no spaces
	 * @param exp: Expression to be parsed
	 * @return: A new expression with spaces added between all operands and operators
	 */
	public static String addSpaces(String infixExp) {
		// Create a new StringBuilder
		StringBuilder newExp = new StringBuilder();
		// Iterate through the string
		for (int i = 0; i < infixExp.length(); i++) {
			// If the character is a digit append it to the StringBuilder
			if (Character.isDigit(infixExp.charAt(i))) {
				newExp.append(infixExp.charAt(i));
				// Check if next character is also a digit, if not, add a space
				if ((i != infixExp.length() - 1) && !Character.isDigit(infixExp.charAt(i + 1))) {
					newExp.append(" ");
				}
			} else {
				// If the operand is a negative number
				if (infixExp.charAt(i) == '-') {
					if (i == 0) {
						newExp.append(infixExp.charAt(i));
					} else if (!Character.isDigit(infixExp.charAt(i - 1)) && infixExp.charAt(i - 1) != ')') {
						newExp.append(infixExp.charAt(i));
					} else { newExp.append(infixExp.charAt(i) + " "); }
				// If the operator is a double operator make sure to include both before adding a space
				} else if (infixExp.charAt(i) == '=' || infixExp.charAt(i) == '!' || infixExp.charAt(i) == '&' ||
						infixExp.charAt(i) == '|') {
					newExp.append(String.format("%s%s ", infixExp.charAt(i), infixExp.charAt(i + 1)));
					// manually advance i
					i++;	
				} else if (infixExp.charAt(i) == '>' || infixExp.charAt(i) == '<') {
					if (infixExp.charAt(i + 1) == '=') {
						newExp.append(String.format("%s%s ", infixExp.charAt(i), infixExp.charAt(i + 1)));
						// manually advance i
						i++;
					} else { newExp.append(infixExp.charAt(i) + " "); }
				} else {
					// Any character that is not a digit is added with a space
					newExp.append(infixExp.charAt(i) + " ");
				}
			}
		}
		return newExp.toString();
	}
	 
	// main program
	public static void main(String[] args) throws IOException {
		// reads in the expression
		FileInputStream inputFile = new FileInputStream("InfixExpression.txt");
		Scanner scanner = new Scanner(inputFile);
		
		System.out.println("Infix Expression Parcer"); // Header
		while (scanner.hasNext()) {
			System.out.println();
			// read in the expression
			String infixExp = scanner.nextLine(); 
			// Output given expression
			System.out.println("Expression given: " + infixExp);
			
			// Remove any spaces from the user
			infixExp = infixExp.replace(" ", "");
			// Add spaces so the expression can be read by the infixToPostfix method
			infixExp = addSpaces(infixExp);
			
			// Convert from infix to postfix
			String postfixToEvaluate = infixToPostfix(infixExp);

			// Evaluate expression and write results to console
			System.out.println("Evaluated Expression: " + evaluate(postfixToEvaluate));
		}

		// never forget to close
		scanner.close();
		inputFile.close();
	}

}